Inventario PHP

#Es un sistema para guardar y ver productos en una lista. te dice si hay stock o si esta agotado.

#como ponerlo a andar

·necesitas xampp o laragon (apache + php + mysql)

·metes la carpeta en www

·creas la base de datos inventario en databases e importas el archivo base_datos.sql

·te conectas a http://localhost/inventario/index.php

#tecnologias 

·php

·mysql

·html y css

#lo que hay que instalar

·xampp / laragon
·navegador web