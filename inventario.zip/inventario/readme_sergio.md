Sistema de Inventario en PHP

#Aplicación web simple para registrar productos, listar existencias y consultar si hay disponibilidad o si el stock está en cero.

#Pasos para ejecutar

·Mueve la carpeta del proyecto a la ruta www (usando XAMPP o Laragon).

·Crea la base de datos inventario e importa el archivo base_datos.sql.

·Abre en tu navegador: http://localhost/inventario/index.php

#Requisitos e instalación

·Servidor local: XAMPP o Laragon (PHP, Apache y MySQL)

·Cualquier navegador web

#Tecnologías

·Backend: PHP

·Base de Datos: MySQL

·Frontend: HTML y CSS